import logging
import os
import traceback

import cv2
import onnx
import numpy as np
from PyQt5 import QtCore
from PyQt5.QtCore import QThread
from PyQt5.QtCore import QCoreApplication

from anylabeling.utils import GenericWorker
from anylabeling.views.labeling.shape import Shape
from anylabeling.views.labeling.utils.opencv import qt_img_to_rgb_cv_img

from .lru_cache import LRUCache
from .model import Model
from .types import AutoLabelingResult
from .sam_onnx import SegmentAnythingONNX
from .sam2_onnx import SegmentAnything2ONNX


class SegmentAnything(Model):
    """Segmentation model using SegmentAnything"""

    class Meta:
        required_config_names = [
            "type",
            "name",
            "display_name",
            "encoder_model_path",
            "decoder_model_path",
        ]
        widgets = [
            "output_label",
            "output_select_combobox",
            "button_segment_all",
            "button_add_point",
            "button_remove_point",
            "button_add_rect",
            "button_clear",
            "button_finish_object",
        ]
        output_modes = {
            "polygon": QCoreApplication.translate("Model", "Polygon"),
            "rectangle": QCoreApplication.translate("Model", "Rectangle"),
        }
        default_output_mode = "polygon"

    def __init__(self, config_path, on_message) -> None:
        # Run the parent class's init method
        super().__init__(config_path, on_message)
        self.input_size = self.config["input_size"]
        self.max_width = self.config["max_width"]
        self.max_height = self.config["max_height"]

        # Get encoder and decoder model paths
        encoder_model_abs_path = self.get_model_abs_path(
            self.config, "encoder_model_path"
        )
        if not encoder_model_abs_path or not os.path.isfile(encoder_model_abs_path):
            raise FileNotFoundError(
                QCoreApplication.translate(
                    "Model",
                    "Could not download or initialize encoder of Segment Anything.",
                )
            )
        decoder_model_abs_path = self.get_model_abs_path(
            self.config, "decoder_model_path"
        )
        if not decoder_model_abs_path or not os.path.isfile(decoder_model_abs_path):
            raise FileNotFoundError(
                QCoreApplication.translate(
                    "Model",
                    "Could not download or initialize decoder of Segment Anything.",
                )
            )

        # Load models
        if self.detect_model_variant(decoder_model_abs_path) == "sam2":
            self.model = SegmentAnything2ONNX(
                encoder_model_abs_path, decoder_model_abs_path
            )
        else:
            self.model = SegmentAnythingONNX(
                encoder_model_abs_path, decoder_model_abs_path
            )

        # Mark for auto labeling
        # points, rectangles
        self.marks = []

        # Cache for image embedding
        self.cache_size = 10
        self.preloaded_size = self.cache_size - 3
        self.image_embedding_cache = LRUCache(self.cache_size)

        # Pre-inference worker
        self.pre_inference_thread = None
        self.pre_inference_worker = None
        self.stop_inference = False

        # Parameters for automatic segmentation
        self.quality_threshold = self.config.get("quality_threshold", 0.8)
        self.nms_threshold = self.config.get("nms_threshold", 0.7)

    def detect_model_variant(self, decoder_model_abs_path):
        """Load and detect model variant based on the model architecture"""
        model = onnx.load(decoder_model_abs_path)
        input_names = [input.name for input in model.graph.input]
        if "high_res_feats_0" in input_names:
            return "sam2"
        return "sam"

    def set_auto_labeling_marks(self, marks):
        """Set auto labeling marks"""
        self.marks = marks

    def post_process(self, masks, offset=(0, 0), min_area=0):
        """
        Post process masks
        """
        # Binarize and smooth masks
        masks = np.where(masks > 0.0, 255, 0).astype(np.uint8)
        kernel = np.ones((3, 3), np.uint8)
        masks = cv2.morphologyEx(masks, cv2.MORPH_OPEN, kernel)
        masks = cv2.morphologyEx(masks, cv2.MORPH_CLOSE, kernel)
        # Find contours
        contours, _ = cv2.findContours(masks, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)

        # Refine contours
        approx_contours = []
        for contour in contours:
            # Approximate contour
            epsilon = 0.001 * cv2.arcLength(contour, True)
            approx = cv2.approxPolyDP(contour, epsilon, True)
            if cv2.contourArea(approx) >= min_area:
                approx_contours.append(approx)

        # Remove too big contours ( >90% of image size)
        if len(approx_contours) > 1:
            image_size = masks.shape[0] * masks.shape[1]
            areas = [cv2.contourArea(contour) for contour in approx_contours]
            filtered_approx_contours = [
                contour
                for contour, area in zip(approx_contours, areas)
                if area < image_size * 0.9
            ]
            approx_contours = filtered_approx_contours

        # Remove small contours (area < 20% of average area)
        if len(approx_contours) > 1:
            areas = [cv2.contourArea(contour) for contour in approx_contours]
            avg_area = np.mean(areas)

            filtered_approx_contours = [
                contour
                for contour, area in zip(approx_contours, areas)
                if area > avg_area * 0.2
            ]
            approx_contours = filtered_approx_contours

        # Contours to shapes
        shapes = []
        ox, oy = offset
        if self.output_mode == "polygon":
            for approx in approx_contours:
                # Scale points
                points = approx.reshape(-1, 2)
                points[:, 0] = points[:, 0]
                points[:, 1] = points[:, 1]
                points = points.tolist()
                if len(points) < 3:
                    continue
                points.append(points[0])

                # Create shape
                shape = Shape(flags={})
                for point in points:
                    point[0] = int(point[0] + ox)
                    point[1] = int(point[1] + oy)
                    shape.add_point(QtCore.QPointF(point[0], point[1]))
                shape.shape_type = "polygon"
                shape.closed = True
                shape.fill_color = "#000000"
                shape.line_color = "#000000"
                shape.line_width = 1
                shape.label = "AUTOLABEL_OBJECT"
                shape.selected = False
                shapes.append(shape)
        elif self.output_mode == "rectangle":
            x_min = 100000000
            y_min = 100000000
            x_max = 0
            y_max = 0
            for approx in approx_contours:
                # Scale points
                points = approx.reshape(-1, 2)
                points[:, 0] = points[:, 0]
                points[:, 1] = points[:, 1]
                points = points.tolist()
                if len(points) < 3:
                    continue

                # Get min/max
                for point in points:
                    x_min = min(x_min, point[0] + ox)
                    y_min = min(y_min, point[1] + oy)
                    x_max = max(x_max, point[0] + ox)
                    y_max = max(y_max, point[1] + oy)

            # Create shape
            shape = Shape(flags={})
            shape.add_point(QtCore.QPointF(x_min, y_min))
            shape.add_point(QtCore.QPointF(x_max, y_max))
            shape.shape_type = "rectangle"
            shape.closed = True
            shape.fill_color = "#000000"
            shape.line_color = "#000000"
            shape.line_width = 1
            shape.label = "AUTOLABEL_OBJECT"
            shape.selected = False
            shapes.append(shape)

        return shapes

    @staticmethod
    def compute_iou(mask1, mask2):
        inter = np.logical_and(mask1 > 0, mask2 > 0).sum()
        union = np.logical_or(mask1 > 0, mask2 > 0).sum()
        if union == 0:
            return 0.0
        return inter / union

    def nms_masks(self, masks, scores):
        idxs = np.argsort(scores)[::-1]
        keep_masks = []
        keep_scores = []
        while idxs.size > 0:
            i = idxs[0]
            keep_masks.append(masks[i])
            keep_scores.append(scores[i])
            remain = []
            for j in idxs[1:]:
                iou = self.compute_iou(masks[i], masks[j])
                if iou < self.nms_threshold:
                    remain.append(j)
            idxs = np.array(remain)
        return keep_masks, keep_scores

    def generate_grid_points(self, size, points_per_side=16):
        h, w = size
        ys = np.linspace(0, h - 1, points_per_side, dtype=int)
        xs = np.linspace(0, w - 1, points_per_side, dtype=int)
        grid = np.stack(np.meshgrid(xs, ys), axis=-1).reshape(-1, 2)
        return grid

    def predict_all_shapes(self, image, filename=None) -> AutoLabelingResult:
        """Predict masks for the entire image without user prompts."""
        if image is None:
            return AutoLabelingResult([], replace=False)

        cv_image = qt_img_to_rgb_cv_img(image, filename)
        height, width = cv_image.shape[:2]

        cfg_points_per_side = 64
        pred_iou_thresh = 0.95
        box_nms_thresh = 0.7
        crop_n_layers = 2
        crop_overlap_ratio = 512 / 1500
        crop_downscale = 1
        min_mask_region_area = 500

        masks_with_scores = []

        for layer in range(crop_n_layers + 1):
            n_crops = 2**layer
            crop_h = height / n_crops
            crop_w = width / n_crops
            overlap_h = crop_h * crop_overlap_ratio
            overlap_w = crop_w * crop_overlap_ratio
            points_side = max(1, int(cfg_points_per_side / (crop_downscale**layer)))

            for y_id in range(n_crops):
                for x_id in range(n_crops):
                    y0 = int(y_id * crop_h - overlap_h / 2)
                    x0 = int(x_id * crop_w - overlap_w / 2)
                    y1 = int((y_id + 1) * crop_h + overlap_h / 2)
                    x1 = int((x_id + 1) * crop_w + overlap_w / 2)

                    y0 = max(0, y0)
                    x0 = max(0, x0)
                    y1 = min(height, y1)
                    x1 = min(width, x1)

                    crop = cv_image[y0:y1, x0:x1]
                    if crop.size == 0:
                        continue

                    embedding = self.model.encode(crop)

                    xs = np.linspace(0, crop.shape[1] - 1, points_side, dtype=int)
                    ys = np.linspace(0, crop.shape[0] - 1, points_side, dtype=int)
                    marks = [
                        {"type": "point", "data": [int(x), int(y)], "label": 1}
                        for y in ys
                        for x in xs
                    ]
                    if not marks:
                        continue
                    masks, qual = self.model.predict_masks(embedding, marks)
                    if masks.ndim == 4:
                        masks = masks[0]
                        qual = qual[0]
                    for mask, score in zip(masks, np.array(qual).ravel()):
                        if score < pred_iou_thresh:
                            continue
                        if (mask > 0).sum() < min_mask_region_area:
                            continue
                        masks_with_scores.append((mask, float(score), x0, y0))

        if not masks_with_scores:
            return AutoLabelingResult([], replace=False)

        masks = np.array([m[0] for m in masks_with_scores])
        scores = np.array([m[1] for m in masks_with_scores])
        offsets = [(m[2], m[3]) for m in masks_with_scores]

        order = list(np.argsort(-scores))
        selected = []
        while order:
            i = order.pop(0)
            selected.append(i)
            if not order:
                break
            i_mask = masks[i] > 0
            ious = [
                (i_mask & (masks[j] > 0)).sum() / (i_mask | (masks[j] > 0)).sum()
                for j in order
            ]
            order = [j for j, iou in zip(order, ious) if iou < box_nms_thresh]

        shapes = []
        for idx in selected:
            ox, oy = offsets[idx]
            shapes.extend(
                self.post_process(
                    masks[idx], offset=(ox, oy), min_area=min_mask_region_area
                )
            )

        return AutoLabelingResult(shapes, replace=False)

        return AutoLabelingResult(shapes, replace=False)
    def predict_shapes(self, image, filename=None) -> AutoLabelingResult:
        """
        Predict shapes from image
        """
        if image is None or not self.marks:
            return AutoLabelingResult([], replace=False)

        shapes = []
        try:
            # Use cached image embedding if possible
            cached_data = self.image_embedding_cache.get(filename)
            if cached_data is not None:
                image_embedding = cached_data
            else:
                cv_image = qt_img_to_rgb_cv_img(image, filename)
                if self.stop_inference:
                    return AutoLabelingResult([], replace=False)
                image_embedding = self.model.encode(cv_image)
                self.image_embedding_cache.put(
                    filename,
                    image_embedding,
                )
            if self.stop_inference:
                return AutoLabelingResult([], replace=False)
            masks, _ = self.model.predict_masks(image_embedding, self.marks)
            if len(masks.shape) == 4:
                masks = masks[0][0]
            else:
                masks = masks[0]
            shapes = self.post_process(masks, min_area=0)
        except Exception as e:  # noqa
            logging.warning("Could not inference model")
            logging.warning(e)
            traceback.print_exc()
            return AutoLabelingResult([], replace=False)

        result = AutoLabelingResult(shapes, replace=False)
        return result

    def unload(self):
        self.stop_inference = True
        if self.pre_inference_thread:
            self.pre_inference_thread.quit()

    def preload_worker(self, files):
        """
        Preload next files, run inference and cache results
        """
        files = files[: self.preloaded_size]
        for filename in files:
            if self.image_embedding_cache.find(filename):
                continue
            image = self.load_image_from_filename(filename)
            if image is None:
                continue
            if self.stop_inference:
                return
            cv_image = qt_img_to_rgb_cv_img(image)
            image_embedding = self.model.encode(cv_image)
            self.image_embedding_cache.put(
                filename,
                image_embedding,
            )

    def on_next_files_changed(self, next_files):
        """
        Handle next files changed. This function can preload next files
        and run inference to save time for user.
        """
        if (
            self.pre_inference_thread is None
            or not self.pre_inference_thread.isRunning()
        ):
            self.pre_inference_thread = QThread()
            self.pre_inference_worker = GenericWorker(self.preload_worker, next_files)
            self.pre_inference_worker.finished.connect(self.pre_inference_thread.quit)
            self.pre_inference_worker.moveToThread(self.pre_inference_thread)
            self.pre_inference_thread.started.connect(self.pre_inference_worker.run)
            self.pre_inference_thread.start()

    def predict_all_shapes(self, image, filename=None) -> AutoLabelingResult:
        """Predict masks for the entire image without user prompts."""
        if image is None:
            return AutoLabelingResult([], replace=False)

        cv_image = qt_img_to_rgb_cv_img(image, filename)
        embedding = self.model.encode(cv_image)

        h, w = embedding["original_size"]
        points_per_side = 32
        scales = [1.0, 0.5]
        all_masks = []
        scores = []

        for scale in scales:
            n = max(1, int(points_per_side * scale))
            xs = np.linspace(0, w - 1, n, dtype=int)
            ys = np.linspace(0, h - 1, n, dtype=int)
            marks = []
            for y in ys:
                for x in xs:
                    marks.append(
                        {"type": "point", "data": [int(x), int(y)], "label": 1}
                    )
            if not marks:
                continue
            masks, qual = self.model.predict_masks(embedding, marks)
            if masks.ndim == 4:
                masks = masks[0]
                qual = qual[0]
            all_masks.extend(masks)
            scores.extend(np.array(qual).ravel().tolist())

        if not all_masks:
            return AutoLabelingResult([], replace=False)

        all_masks = np.array(all_masks)
        scores = np.array(scores)

        # Filter by quality score
        keep = scores > 0.1
        all_masks = all_masks[keep]
        scores = scores[keep]

        # Non-maximum suppression
        order = list(np.argsort(-scores))
        selected = []
        while order:
            i = order.pop(0)
            selected.append(i)
            if not order:
                break
            ious = np.array(
                [
                    np.logical_and(all_masks[i] > 0, all_masks[j] > 0).sum()
                    / np.logical_or(all_masks[i] > 0, all_masks[j] > 0).sum()
                    for j in order
                ]
            )
            order = [j for j, iou in zip(order, ious) if iou < 0.7]

        shapes = []
        for idx in selected:
            shapes.extend(self.post_process(all_masks[idx]))

        return AutoLabelingResult(shapes, replace=False)
