<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>AutoLabelingWidget</name>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling.py" line="114"/>
        <source>No Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling.py" line="115"/>
        <source>...Load Custom Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling.py" line="119"/>
        <source>(User) </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BrightnessContrastDialog</name>
    <message>
        <location filename="../../views/labeling/widgets/brightness_contrast_dialog.py" line="17"/>
        <source>Brightness/Contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/brightness_contrast_dialog.py" line="23"/>
        <source>Brightness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/brightness_contrast_dialog.py" line="24"/>
        <source>Contrast</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Canvas</name>
    <message>
        <location filename="../../views/labeling/widgets/canvas.py" line="103"/>
        <source>Loading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/canvas.py" line="225"/>
        <source>Auto Labeling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/canvas.py" line="227"/>
        <source>Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/canvas.py" line="229"/>
        <source>Editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/canvas.py" line="231"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/canvas.py" line="349"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/canvas.py" line="364"/>
        <source>Click &amp; drag to move point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/canvas.py" line="376"/>
        <source>Click to create point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/canvas.py" line="388"/>
        <source>Click &amp; drag to move shape &apos;%s&apos;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportDialog</name>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="38"/>
        <source>Export Annotations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="47"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="52"/>
        <source>YOLO (.txt)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="53"/>
        <source>COCO (.json)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="54"/>
        <source>Pascal VOC (.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="55"/>
        <source>CreateML</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="61"/>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="65"/>
        <source>Current Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="67"/>
        <source>Select Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="101"/>
        <source>Browse...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="87"/>
        <source>Search recursively in subfolders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="94"/>
        <source>Output Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="107"/>
        <source>Export Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="112"/>
        <source>Use random names (UUID4) for exported items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="115"/>
        <source>Generate unique identifiers for exported files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="123"/>
        <source>Data Split</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="127"/>
        <source>Split data into train/val/test sets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="134"/>
        <source>Train:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="144"/>
        <source>Val:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="154"/>
        <source>Test:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="168"/>
        <source>Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="177"/>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="185"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="488"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="226"/>
        <source>Select Source Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="237"/>
        <source>Select Output Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="312"/>
        <source>Missing Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="312"/>
        <source>Please select a source folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="321"/>
        <source>Missing Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="321"/>
        <source>Please select an output folder.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="335"/>
        <source>Same Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="335"/>
        <source>Source and output folders are the same. This may overwrite files. Continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="353"/>
        <source>Invalid Split Ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="353"/>
        <source>Split ratios must add up to 100%.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="410"/>
        <source>Cancel Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="410"/>
        <source>Export is in progress. Are you sure you want to cancel?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="419"/>
        <source>Cancelling...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="425"/>
        <source>Starting export...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="431"/>
        <source>Export completed!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="434"/>
        <source>Export Completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="434"/>
        <source>Annotations have been exported to {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="448"/>
        <source>Error: {}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="450"/>
        <source>Export Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="450"/>
        <source>An error occurred during export:
{}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/export_dialog.py" line="488"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LabelDialog</name>
    <message>
        <location filename="../../views/labeling/widgets/label_dialog.py" line="42"/>
        <source>Enter object label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/label_dialog.py" line="56"/>
        <source>Group ID</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LabelingWidget</name>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="191"/>
        <source>Flags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="208"/>
        <source>Objects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="216"/>
        <source>Select label to start annotating for it. Press &apos;Esc&apos; to deselect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="225"/>
        <source>Labels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="233"/>
        <source>Search Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="242"/>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="281"/>
        <source>&amp;Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="281"/>
        <source>Open image or label file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="288"/>
        <source>&amp;Open Dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="288"/>
        <source>Open Dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="295"/>
        <source>&amp;Next Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="295"/>
        <source>Open next (hold Ctrl+Shift to copy labels)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="303"/>
        <source>&amp;Prev Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="303"/>
        <source>Open prev (hold Ctrl+Shift to copy labels)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="311"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="311"/>
        <source>Save labels to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="319"/>
        <source>&amp;Save As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="319"/>
        <source>Save labels to a different file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="328"/>
        <source>&amp;Delete File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="328"/>
        <source>Delete current label file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="337"/>
        <source>&amp;Change Output Dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="337"/>
        <source>Change where annotations are loaded/saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="345"/>
        <source>Save &amp;Automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="345"/>
        <source>Save automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="355"/>
        <source>Save With Image Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="355"/>
        <source>Save image data in label file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="364"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="364"/>
        <source>Close current file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="372"/>
        <source>Keep Previous Annotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="392"/>
        <source>Create Polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="392"/>
        <source>Start drawing polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="400"/>
        <source>Create Rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="400"/>
        <source>Start drawing rectangles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="408"/>
        <source>Create Circle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="408"/>
        <source>Start drawing circles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="416"/>
        <source>Create Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="416"/>
        <source>Start drawing lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="424"/>
        <source>Create Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="424"/>
        <source>Start drawing points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="432"/>
        <source>Create LineStrip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="432"/>
        <source>Start drawing linestrip. Ctrl+LeftClick ends creation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="440"/>
        <source>Edit Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="440"/>
        <source>Move and edit the selected polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="448"/>
        <source>Group Selected Shapes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="448"/>
        <source>Group shapes by assigning a same group_id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="456"/>
        <source>Ungroup Selected Shapes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="456"/>
        <source>Ungroup shapes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="465"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="465"/>
        <source>Delete the selected polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="473"/>
        <source>Duplicate Polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="473"/>
        <source>Create a duplicate of the selected polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="481"/>
        <source>Copy Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="481"/>
        <source>Copy selected polygons to clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="489"/>
        <source>Paste Object</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="489"/>
        <source>Paste copied polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="497"/>
        <source>Undo last point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="497"/>
        <source>Undo last drawn point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="505"/>
        <source>Remove Selected Point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="505"/>
        <source>Remove selected point from polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="514"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="514"/>
        <source>Undo last add and edit of shape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="523"/>
        <source>&amp;Hide
Polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="523"/>
        <source>Hide all polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="530"/>
        <source>&amp;Show
Polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="530"/>
        <source>Show all polygons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="538"/>
        <source>&amp;Documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="538"/>
        <source>Show documentation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="545"/>
        <source>&amp;Contact me</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="545"/>
        <source>Show contact page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="554"/>
        <source>Zoom in or out of the image. Also accessible with {} and {} from the canvas.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="554"/>
        <source>Ctrl+Wheel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="567"/>
        <source>Zoom &amp;In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="567"/>
        <source>Increase zoom level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="575"/>
        <source>&amp;Zoom Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="575"/>
        <source>Decrease zoom level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="583"/>
        <source>&amp;Original size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="583"/>
        <source>Zoom to original size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="591"/>
        <source>&amp;Keep Previous Scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="591"/>
        <source>Keep previous zoom scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="599"/>
        <source>&amp;Fit Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="599"/>
        <source>Zoom follows window size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="608"/>
        <source>Fit &amp;Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="608"/>
        <source>Zoom follows window width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="617"/>
        <source>&amp;Brightness Contrast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="625"/>
        <source>&amp;Show Cross Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="625"/>
        <source>Show cross line for mouse position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="634"/>
        <source>&amp;Show Groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="634"/>
        <source>Show shape groups</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="643"/>
        <source>&amp;Show Texts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="643"/>
        <source>Show text above shapes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="753"/>
        <source>&amp;Edit Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="753"/>
        <source>Modify the label of the selected polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="762"/>
        <source>Fill Drawing Polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="762"/>
        <source>Fill polygon while drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="774"/>
        <source>&amp;Auto Labeling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="774"/>
        <source>Auto Labeling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="902"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="902"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="902"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="902"/>
        <source>&amp;Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="902"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="902"/>
        <source>Open &amp;Recent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="1125"/>
        <source>Please wait...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="1243"/>
        <source>Please restart the application to apply changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="1248"/>
        <source>Mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="1249"/>
        <source>Shortcuts:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="1250"/>
        <source>Previous:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="1251"/>
        <source>Next:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="1252"/>
        <source>Rectangle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="1253"/>
        <source>Polygon:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2806"/>
        <source>Invalid label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2806"/>
        <source>Invalid label &apos;{}&apos; with validation type &apos;{}&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="1814"/>
        <source>Error saving label data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="1814"/>
        <source>&lt;b&gt;%s&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2118"/>
        <source>Error opening file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2072"/>
        <source>No such file: &lt;b&gt;%s&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2079"/>
        <source>Loading %s...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2088"/>
        <source>&lt;p&gt;&lt;b&gt;%s&lt;/b&gt;&lt;/p&gt;&lt;p&gt;Make sure &lt;i&gt;%s&lt;/i&gt; is a valid label file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2125"/>
        <source>Error reading %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2118"/>
        <source>&lt;p&gt;Make sure &lt;i&gt;{0}&lt;/i&gt; is a valid image file.&lt;br/&gt;Supported image formats: {1}&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2185"/>
        <source>Loaded %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2356"/>
        <source>Image &amp; Label files (%s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2362"/>
        <source>%s - Choose Image or Label file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2379"/>
        <source>%s - Save/Load Annotations in Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2393"/>
        <source>%s . Annotations will be saved/loaded in %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2423"/>
        <source>%s - Choose File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2444"/>
        <source>Label files (*%s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2444"/>
        <source>Choose File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2478"/>
        <source>You are about to permanently delete this label file, proceed anyway?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2564"/>
        <source>Attention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2516"/>
        <source>Save annotations to &quot;{self.filename!r}&quot; before closing?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2517"/>
        <source>Save annotations?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2561"/>
        <source>You are about to permanently delete {} polygons, proceed anyway?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2594"/>
        <source>%s - Open Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2864"/>
        <source>Object Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2869"/>
        <source>Image Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2876"/>
        <source>Switch to Edit mode for text editing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="372"/>
        <source>Toggle &quot;Keep Previous Annotation&quot; mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="382"/>
        <source>Auto Use Last Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="382"/>
        <source>Toggle &quot;Auto Use Last Label&quot; mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="882"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="891"/>
        <source>Export Annotations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="891"/>
        <source>Export annotations to other formats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="902"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="175"/>
        <source>Text Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="653"/>
        <source>&amp;Reset Views</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="653"/>
        <source>Reset dock widgets layout to default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="700"/>
        <source>System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="708"/>
        <source>Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="716"/>
        <source>Dark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="902"/>
        <source>&amp;Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="1037"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2978"/>
        <source>Dock layout reset to default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/label_widget.py" line="2997"/>
        <source>Please restart the application to apply the theme change.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Model</name>
    <message>
        <location filename="../../services/auto_labeling/model.py" line="32"/>
        <source>Rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="297"/>
        <source>Downloading {download_url}: {percent}%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/segment_anything.py" line="44"/>
        <source>Polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/yolov8.py" line="44"/>
        <source>Could not download or initialize YOLOv8 model.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model.py" line="42"/>
        <source>Config file not found: {model_config}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model.py" line="52"/>
        <source>Unknown config type: {type}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/yolov5.py" line="44"/>
        <source>Could not download or initialize YOLOv5 model.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModelManager</name>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="144"/>
        <source>Model loaded. Ready for labeling.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="242"/>
        <source>No model selected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="258"/>
        <source>Loading model: {model_name}. Please wait...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="484"/>
        <source>Model is not loaded. Choose a mode to continue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="470"/>
        <source>Error in model prediction. Please check the model.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="473"/>
        <source>Finished inferencing AI model. Check the result.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="488"/>
        <source>Inferencing AI model. Please wait...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="496"/>
        <source>Another model is being executed. Please wait for it to finish.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="165"/>
        <source>Error in loading custom model: Invalid path.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="176"/>
        <source>Error in loading custom model: Invalid config file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="186"/>
        <source>Error in loading custom model: Invalid config file format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="252"/>
        <source>Error in loading model: Invalid model name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="418"/>
        <source>Error in loading model: {error_message}</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="275"/>
        <source>Error in loading config file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="284"/>
        <source>Missing download_url in config file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../services/auto_labeling/model_manager.py" line="324"/>
        <source>Could not find config.yaml in zip file.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ZoomWidget</name>
    <message>
        <location filename="../../views/labeling/widgets/zoom_widget.py" line="11"/>
        <source>Zoom Level</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>auto_labeling_form</name>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling_ui.py" line="107"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling_ui.py" line="108"/>
        <source>Auto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling_ui.py" line="109"/>
        <source>No Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling_ui.py" line="110"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling_ui.py" line="111"/>
        <source>polygon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling_ui.py" line="112"/>
        <source>rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling_ui.py" line="113"/>
        <source>Run (i)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling_ui.py" line="114"/>
        <source>+Point (Q)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling_ui.py" line="115"/>
        <source>-Point (E)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling_ui.py" line="116"/>
        <source>+Rect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling_ui.py" line="117"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling_ui.py" line="118"/>
        <source>Finish Object (f)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../views/labeling/widgets/auto_labeling/auto_labeling_ui.py" line="119"/>
        <source>Ready!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
