from .auto_labeling import AutoLabelingWidget

__all__ = ["AutoLabelingWidget"]
